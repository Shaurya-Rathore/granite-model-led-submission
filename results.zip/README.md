# Saved results

`default/` contains the six public items and the measured 1x/3x answers,
official scores and raw-response traces. Each budget is one sampled run.
The three `short-guide-*` folders contain separate diagnostic trials.
`context-probe.json` records the matched clue-isolation experiment.
`runs.json` records sampling settings, run counts and original manifest hashes.

Answer, score, trace and item files are unchanged from the sealed development
snapshot. Summary files omit obsolete source inventories and test metadata.
These files are evidence only; the inference runner never loads them.
