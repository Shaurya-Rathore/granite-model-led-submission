# Saved results and public inputs

- default/: six selected items, measured 1x/3x answers, scores and raw traces.
- short-guide-*/: separate screen, correction and failed-repeat trials.
- public/: original 60 public items and scoring key, unchanged.
- measured-results.md: measured results, case matrix and evaluation scope.
- context-probe.json and runs.json: experiment summaries and run metadata.
- source-hashes.json: packaged source and evidence hashes.

The scorer is model_solver/score.py in the submission. Extract this archive with
`python3 -m zipfile -e results.zip results` from the submission root.
The inference runner never loads this evidence or the scoring key.
